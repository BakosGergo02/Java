import java.util.List;

public class PyUtilsTests {
    public static void main(String[] args) {
        test_range_withEnd();
        test_range_withStartAndEnd();
        test_range_withStartEndAndStep();
        test_range_withZeroStep();
        test_range_withNegativeStep();
        test_range_withDescendingOrder();
        test_range_withNoElements();
    }

    private static void test_range_withEnd() {
        // arrange
        int end = 5;

        // act
        List<Integer> result = PyUtils.range(end);

        // assert
        List<Integer> expected = List.of(0, 1, 2, 3, 4);
        assert result.equals(expected) : "Expected " + expected + ", but got " + result;
        System.out.println("test_range_withEnd - OK");
    }

    private static void test_range_withStartAndEnd() {
        // arrange
        int start = 3, end = 7;

        // act
        List<Integer> result = PyUtils.range(start, end);

        // assert
        List<Integer> expected = List.of(3, 4, 5, 6);
        assert result.equals(expected) : "Expected " + expected + ", but got " + result;
        System.out.println("test_range_withStartAndEnd - OK");
    }

    private static void test_range_withStartEndAndStep() {
        // arrange
        int start = 4, end = 20, step = 2;

        // act
        List<Integer> result = PyUtils.range(start, end, step);

        // assert
        List<Integer> expected = List.of(4, 6, 8, 10, 12, 14, 16, 18);
        assert result.equals(expected) : "Expected " + expected + ", but got " + result;
        System.out.println("test_range_withStartEndAndStep - OK");
    }

    private static void test_range_withZeroStep() {
        try {
            // arrange
            int start = 0, end = 10, step = 0;

            // act
            PyUtils.range(start, end, step);

            // assert
            assert false : "Expected IllegalArgumentException for step=0";
        } catch (IllegalArgumentException e) {
            System.out.println("test_range_withZeroStep - OK");
        }
    }

    private static void test_range_withNegativeStep() {
        try {
            // arrange
            int start = 0, end = 10, step = -1;

            // act
            PyUtils.range(start, end, step);

            // assert
            assert false : "Expected IllegalArgumentException for negative step";
        } catch (IllegalArgumentException e) {
            System.out.println("test_range_withNegativeStep - OK");
        }
    }

    private static void test_range_withDescendingOrder() {
        // arrange
        int start = 10, end = 4, step = 1;

        // act
        List<Integer> result = PyUtils.range(start, end, step);

        // assert
        List<Integer> expected = List.of(); // Descending order, no elements generated
        assert result.equals(expected) : "Expected " + expected + ", but got " + result;
        System.out.println("test_range_withDescendingOrder - OK");
    }

    private static void test_range_withNoElements() {
        // arrange
        int start = 3, end = 3;

        // act
        List<Integer> result = PyUtils.range(start, end);

        // assert
        List<Integer> expected = List.of(); // No elements as start == end
        assert result.equals(expected) : "Expected " + expected + ", but got " + result;
        System.out.println("test_range_withNoElements - OK");
    }
}
