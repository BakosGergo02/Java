public class Main {
    public static void main(String[] args) {
        System.out.println(calculateSum("123", "3.14", "7.89", "a"));
    }

    public static double calculateSum(String longValue, String floatValue, String doubleValue, String charValue) {
        long a = Long.parseLong(longValue);
        float b = Float.parseFloat(floatValue);
        double c = Double.parseDouble(doubleValue);
        char d = charValue.charAt(0);
        return a + b + c + d;
    }
}
