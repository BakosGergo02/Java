public class MainTests {
    public static void main(String[] args) {
        test_calculateSum_validInputs();
        test_calculateSum_emptyString();
        test_calculateSum_invalidNumber();
        test_calculateSum_nonCharInput();
    }

    private static void test_calculateSum_validInputs() {
        // arrange
        String longValue = "123";
        String floatValue = "3.14";
        String doubleValue = "7.89";
        String charValue = "a";

        // act
        double result = Main.calculateSum(longValue, floatValue, doubleValue, charValue);

        // assert
        double expected = 123 + 3.14 + 7.89 + 'a'; // 'a' = 97 in ASCII
        assert result == expected : "Expected " + expected + ", but got " + result;
        System.out.println("test_calculateSum_validInputs - OK");
    }

    private static void test_calculateSum_emptyString() {
        try {
            // arrange
            String longValue = "123";
            String floatValue = "3.14";
            String doubleValue = "7.89";
            String charValue = "";

            // act
            Main.calculateSum(longValue, floatValue, doubleValue, charValue);

            // assert
            assert false : "Expected StringIndexOutOfBoundsException";
        } catch (StringIndexOutOfBoundsException e) {
            System.out.println("test_calculateSum_emptyString - OK");
        }
    }

    private static void test_calculateSum_invalidNumber() {
        try {
            // arrange
            String longValue = "abc"; // Invalid long value
            String floatValue = "3.14";
            String doubleValue = "7.89";
            String charValue = "a";

            // act
            Main.calculateSum(longValue, floatValue, doubleValue, charValue);

            // assert
            assert false : "Expected NumberFormatException";
        } catch (NumberFormatException e) {
            System.out.println("test_calculateSum_invalidNumber - OK");
        }
    }

    private static void test_calculateSum_nonCharInput() {
        try {
            // arrange
            String longValue = "123";
            String floatValue = "3.14";
            String doubleValue = "7.89";
            String charValue = "abc"; // More than one character

            // act
            Main.calculateSum(longValue, floatValue, doubleValue, charValue);

            // assert
            assert false : "Expected StringIndexOutOfBoundsException";
        } catch (StringIndexOutOfBoundsException e) {
            System.out.println("test_calculateSum_nonCharInput - OK");
        }
    }
}
