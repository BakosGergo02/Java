import java.util.List;

/*
 * TODO
 * 
 * HF #1 :randrange
 * HF #2: RandUtils.randrange()
 * HF #3: RnadUtils.choice()
 * 
 */

public class Main{

    public static void main(String[] args) {
        for (int i = 0; i < 5; i++) {
                System.out.printf("%d ",RandUtils.randint(70,72));
        }
        System.out.println();

        for (int i = 0; i < 5; i++) {
            System.out.printf("%d ",RandUtils.randrange(1, 10));
        }
        System.out.println();
        int result = RandUtils.choice(List.of(1,2,3,4,5,6));

        System.out.printf("Random choice: %d\n",result);


    }

}