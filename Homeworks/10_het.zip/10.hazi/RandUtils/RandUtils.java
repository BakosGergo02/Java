import java.util.List;
import java.util.Random;

public class RandUtils {

    private final static Random r = new Random();
    public static int randint(int also,int felso)
    {
        int intervallum = felso -also +1;
        int veletlen = r.nextInt(intervallum);
        return also + veletlen;
    }
    public static int randrange(int start, int stop) {
        return randint(start, stop - 1);
    }
    public static Integer choice(List<Integer> list) {
        int index = r.nextInt(list.size());
        return list.get(index);
    }
}
