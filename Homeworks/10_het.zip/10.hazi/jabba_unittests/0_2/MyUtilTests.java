public class MyUtilTests {
    public static void main(String[] args) {
        test_duplaz_withPositiveNumber();
        test_duplaz_withZero();
        test_duplaz_withNegativeNumber();
        test_strlen_withRegularString();
        test_strlen_withEmptyString();
        test_strlen_withSpecialCharacters();
        test_strlen_withNull();
    }

    private static void test_duplaz_withPositiveNumber() {
        // arrange
        int input = 6;

        // act
        int result = MyUtils.duplaz(input);

        // assert
        assert result == 12 : "Expected 12, but got " + result;
        System.out.println("duplaz pozitiv - OK");
    }

    private static void test_duplaz_withZero() {
        // arrange
        int input = 0;

        // act
        int result = MyUtils.duplaz(input);

        // assert
        assert result == 0 : "Expected 0, but got " + result;
        System.out.println("duplaz nulla - OK");
    }

    private static void test_duplaz_withNegativeNumber() {
        // arrange
        int input = -4;

        // act
        int result = MyUtils.duplaz(input);

        // assert
        assert result == -8 : "Expected -8, but got " + result;
        System.out.println("duplaz negativ - OK");
    }

    private static void test_strlen_withRegularString() {
        // arrange
        String input = "hellóka";

        // act
        int result = MyUtils.strlen(input);

        // assert
        assert result == 7 : "Expected 7, but got " + result;
        System.out.println("strlen - OK");
    }

    private static void test_strlen_withEmptyString() {
        // arrange
        String input = "";

        // act
        int result = MyUtils.strlen(input);

        // assert
        assert result == 0 : "Expected 0, but got " + result;
        System.out.println("strlen empty string - OK");
    }

    private static void test_strlen_withSpecialCharacters() {
        // arrange
        String input = "@!#$";

        // act
        int result = MyUtils.strlen(input);

        // assert
        assert result == 4 : "Expected 4, but got " + result;
        System.out.println("strlen special characters - OK");
    }

    private static void test_strlen_withNull() {
        // arrange
        String input = null;

        try {
            // act
            MyUtils.strlen(input);
            assert false : "Expected NullPointerException, but no exception was thrown.";
        } catch (NullPointerException e) {
            // assert
            System.out.println("strlen null - OK");
        }
    }
}
