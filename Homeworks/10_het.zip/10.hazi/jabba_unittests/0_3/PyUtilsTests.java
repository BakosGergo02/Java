import java.util.List;

public class PyUtilsTests {
    public static void main(String[] args) {
        test_range_withStartEndStep();
        test_range_withStartEnd();
        test_range_withEnd();
        test_range_withInvalidRange();
    }

    private static void test_range_withStartEndStep() {
        // arrange
        int start = 4, end = 20, step = 2;

        // act
        List<Integer> result = PyUtils.range(start, end, step);

        // assert
        assert result.equals(List.of(4, 6, 8, 10, 12, 14, 16, 18)) : "Expected [4, 6, 8, 10, 12, 14, 16, 18], but got " + result;
        System.out.println("range with start, end, and step - OK");
    }

    private static void test_range_withStartEnd() {
        // arrange
        int start = 3, end = 7;

        // act
        List<Integer> result = PyUtils.range(start, end);

        // assert
        assert result.equals(List.of(3, 4, 5, 6)) : "Expected [3, 4, 5, 6], but got " + result;
        System.out.println("range with start and end - OK");
    }

    private static void test_range_withEnd() {
        // arrange
        int end = 5;

        // act
        List<Integer> result = PyUtils.range(end);

        // assert
        assert result.equals(List.of(0, 1, 2, 3, 4)) : "Expected [0, 1, 2, 3, 4], but got " + result;
        System.out.println("range with end only - OK");
    }

    private static void test_range_withInvalidRange() {
        // arrange
        int start = 10, end = 4, step = 1;

        // act
        List<Integer> result = PyUtils.range(start, end, step);

        // assert
        assert result.isEmpty() : "Expected an empty list, but got " + result;
        System.out.println("range with invalid range - OK");
    }
}
