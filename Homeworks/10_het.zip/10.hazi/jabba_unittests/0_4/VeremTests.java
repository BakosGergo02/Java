public class VeremTests {
    public static void main(String[] args) {
        test_Size();
        test_append();
        test_isEmpty();
        test_pop();
    }

    private static void test_Size() // ShouldReturnWithTheSizeOfTheStack
    {
        // arrange, act ,assert

        // arrange (uut - unit under test sut - system under test)
        Verem uut = new Verem();

        // act
        int result = uut.size();

        // assert
        assert result == 0;
        System.out.println("size test - OK");
    }

    private static void test_append(){

        // arrange
        Verem uut = new Verem();

        // act
        uut.append(5);

        // assert
        assert uut.size() == 1;
        assert uut.isEmpty() == false;
        assert uut.toString().equals("[5");

        System.out.println("append test - OK");

    }

    private static void test_pop() // ShouldReturnWithTheSizeOfTheStack
    {
        // arrange, act ,assert

        // arrange (uut - unit under test sut - system under test)
        Verem uut = new Verem();

        // act
        uut.append(5);
        uut.pop();

        // assert
        assert uut.size() == 0;
        assert uut.isEmpty() == true;
        System.out.println("pop test - OK");
    }

    private static void test_isEmpty() // ShouldReturnWithTheSizeOfTheStack
    {
        // arrange, act ,assert

        // arrange (uut - unit under test sut - system under test)
        Verem uut = new Verem();

        // act
        boolean result = uut.isEmpty();

        // assert
        assert result == true;
        System.out.println("isEmpty test - OK");
    }

}
