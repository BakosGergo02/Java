public class MainTests {
    public static void main(String[] args) {
        test_product_noArguments();
        test_product_singleArgument();
        test_product_twoArguments();
        test_product_threeArguments();
        test_product_fourArguments();
    }

    private static void test_product_noArguments() {
        // arrange
        // No arguments are needed here.

        // act
        int result = Main.product();

        // assert
        assert result == 1 : "Expected 1, but got " + result;
        System.out.println("product with no arguments - OK");
    }

    private static void test_product_singleArgument() {
        // arrange
        int arg = 2;

        // act
        int result = Main.product(arg);

        // assert
        assert result == 2 : "Expected 2, but got " + result;
        System.out.println("product with single argument - OK");
    }

    private static void test_product_twoArguments() {
        // arrange
        int arg1 = 2, arg2 = 5;

        // act
        int result = Main.product(arg1, arg2);

        // assert
        assert result == 10 : "Expected 10, but got " + result;
        System.out.println("product with two arguments - OK");
    }

    private static void test_product_threeArguments() {
        // arrange
        int arg1 = 2, arg2 = 5, arg3 = 10;

        // act
        int result = Main.product(arg1, arg2, arg3);

        // assert
        assert result == 100 : "Expected 100, but got " + result;
        System.out.println("product with three arguments - OK");
    }

    private static void test_product_fourArguments() {
        // arrange
        int arg1 = 2, arg2 = 5, arg3 = 10, arg4 = 3;

        // act
        int result = Main.product(arg1, arg2, arg3, arg4);

        // assert
        assert result == 300 : "Expected 300, but got " + result;
        System.out.println("product with four arguments - OK");
    }
}
