import java.util.*;

public class duplikatum {
    public static void main(String[] args) {
        // Adott lista
        List<Integer> numbers = Arrays.asList(5, 2, 3, 5, 1, 4, -200, 5, 1, 3, 2, 2, 5);

        // Duplikátumok eltávolítása Set használatával
        Set<Integer> uniqueNumbers = new HashSet<>(numbers);

        // Eredmény lista létrehozása és rendezése
        List<Integer> resultList = new ArrayList<>(uniqueNumbers);
        Collections.sort(resultList);

        // Eredmény kiíratása
        System.out.println(resultList);
    }
}
