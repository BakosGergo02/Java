import java.io.*;
import java.util.*;

public class elofordulas {
    public static void main(String[] args) {
        String filePath = "szavak.txt";

        try {
            BufferedReader reader = new BufferedReader(new FileReader(filePath));
            Map<String, Integer> wordCount = new HashMap<>();

            String line;
            while ((line = reader.readLine()) != null) {
                String[] words = line.split("\\s+");
                for (String word : words) {
                    wordCount.put(word, wordCount.getOrDefault(word, 0) + 1);
                }
            }
            reader.close();

            String mostFrequentWord = null;
            int maxFrequency = 0;

            for (Map.Entry<String, Integer> entry : wordCount.entrySet()) {
                System.out.println(entry.getKey() + ": " + entry.getValue());
                if (entry.getValue() > maxFrequency) {
                    mostFrequentWord = entry.getKey();
                    maxFrequency = entry.getValue();
                }
            }

            System.out.println("\nLeggyakrabban előforduló szó: " + mostFrequentWord + ", " + maxFrequency + " alkalommal");

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
