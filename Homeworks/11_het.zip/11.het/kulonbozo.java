import java.io.*;
import java.util.*;

public class kulonbozo {
    public static void main(String[] args) {
        String filePath = "szavak.txt";

        try {
            BufferedReader reader = new BufferedReader(new FileReader(filePath));
            Set<String> uniqueWords = new HashSet<>();

            String line;
            while ((line = reader.readLine()) != null) {
                String[] words = line.split("\\s+");
                uniqueWords.addAll(Arrays.asList(words));
            }

            reader.close();

            System.out.println("Különböző szavak száma: " + uniqueWords.size());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
