import java.io.*;
import java.util.*;

public class zhgenerator {
    private static final int NUMBER_OF_LINES = 20;
    private static final int WORDS_PER_LINE = 20;

    public static void main(String[] args) {

        String filePath = "zh_words.txt";

        try {
            BufferedWriter writer = new BufferedWriter(new FileWriter(filePath));
            Random random = new Random();

            for (int i = 0; i < NUMBER_OF_LINES; i++) {
                StringBuilder line = new StringBuilder();

                for (int j = 0; j < WORDS_PER_LINE; j++) {
                    char firstChar = (char) ('a' + random.nextInt(3));
                    char secondChar = (char) ('0' + random.nextInt(10));
                    line.append(firstChar).append(secondChar);

                    if (j < WORDS_PER_LINE - 1) {
                        line.append(" ");
                    }
                }

                writer.write(line.toString());
                writer.newLine();
            }

            writer.close();
            System.out.println("Adathalmaz generálása kész. Fájl: " + filePath);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
