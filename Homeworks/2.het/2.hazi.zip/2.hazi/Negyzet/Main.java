import java.util.Scanner;

public class Main
{
    public static void main(String[] args)
    {
        System.out.printf("Hosszát adjuk át: ");
        Scanner input = new Scanner(System.in);
        int a = input.nextInt();

        Negyzet negyzet = new Negyzet(a);    // a konstruktornak a négyzet oldalának a hosszát adjuk át
        int k = negyzet.kerulet();    // 12
        int t = negyzet.terulet();    // 9
        input.close();
        System.out.printf("Kerület: %d\nTerület: %d\n", k , t);
    }
}
class Negyzet
{
    public int oldal;
    public Negyzet(int a)
    {
        this.oldal=a;
    }
    public int kerulet()
    {
        return 4 * this.oldal;
    }
    public int terulet()
    {
        return this.oldal * this.oldal;
    }
}