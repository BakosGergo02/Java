import java.util.Scanner;

class Gomb
{
    public double radius;
    public Gomb(double r)
    {
        this.radius = r;
        }
        public double Felszin()
        {
            return 4*this.radius * this.radius * Math.PI;
        }
        public double Terfogata()
        {
            return (4 * this.radius * this.radius * this.radius * Math.PI) / 3;
    }
}

public class Main
{
    public static void main(String[] args)
    {
        System.out.printf("Adja meg a gömb át mérőjét: ");
        Scanner input = new Scanner(System.in);
        double r = input.nextDouble();

        Gomb circle = new Gomb(r);
        double f = circle.Felszin();
        double t = circle.Terfogata();
        System.out.printf("Felszín: %.2f cm2\nTérfogat: %.2f cm3\n", f, t);
        input.close();
    }
}