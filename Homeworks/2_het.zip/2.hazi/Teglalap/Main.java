import java.util.Scanner;

public class Main
{
    public static void main(String[] args)
    {
        System.out.printf("Adja meg A oldal hosszát: ");
        Scanner input = new Scanner(System.in);
        int a = input.nextInt();
        System.out.printf("Adja meg B oldal hosszát: ");
        int b = input.nextInt();

        Teglalap Teglalap = new Teglalap(a,b);    // a konstruktornak a négyzet oldalának a hosszát adjuk át
        int k = Teglalap.kerulet();    // 12
        int t = Teglalap.terulet();    // 9
        input.close();
        System.out.printf("Kerület: %d\nTerület: %d\n", k , t);
    }
}
class Teglalap
{
    public int aOldal;
    public int bOldal;
    public Teglalap(int a, int b)
    {
        this.aOldal=a;
        this.bOldal=b;
    }
    public int kerulet()
    {
        return 2*(this.aOldal + this.bOldal);
    }
    public int terulet()
    {
        return this.aOldal * this.bOldal;
    }
}