public class Main
{
    public static void main(String[] args)
    {
        int n = 100;
        FizzBuzz fb = new FizzBuzz(); // 100: felső limit, vagyis 1-től 100-ig dolgozzuk fel a számokat
        fb.fizzBuzz(n);                      // C#: fb.Start();
    }
}
class FizzBuzz
{
    public void fizzBuzz(int n)
    {
        for (int i = 1; i <= n; i++)
        {
        if (i % 3 == 0 && i % 5 == 0)
            {
                System.out.println("FizzBuzz");
            }
            else if (i % 3 == 0)
            {
                System.out.println("Fizz");
            }
            else if (i % 5 == 0)
            {
                System.out.println("Buzz");
            }
            else
            {
                System.out.println(i);
            }
        }
    }
}