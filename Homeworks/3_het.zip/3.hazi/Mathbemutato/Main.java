import java.util.Scanner;

import static java.lang.Math.cos;
import static java.lang.Math.abs;
import static java.lang.Math.sqrt;
import static java.lang.Math.max;

public class Main
{
    public static void main(String[] args)
    {
        System.out.println("Adjon meg egy számot:");
        Scanner input = new Scanner(System.in);
        int szam = input.nextInt();
        System.out.printf("A megadott szám abszolút értéke (abs(szám) fügvénnyel végezhető): %d\n",abs(szam));
        System.out.println("Adjon meg egy szöget: ");
        double szog = input.nextInt();
        System.out.printf("A megadott szög koszinusz értéke (cos(szög) fügvénnyel végezhető): %f\n",cos(szog));
        System.out.println("Adjon meg egy számot: ");
        double szam2 = input.nextInt();
        System.out.printf("A megadott szám gyöke(sqrt(szám) fügvénnyel végezhető): %.2f\n",sqrt(szam2));
        System.out.println("Adjon meg ket szamot: ");
        int szam3 = input.nextInt();
        int szam4 = input.nextInt();
        System.out.printf("A megadott számok legnagyobb eleme(Max(szám)): %d\n", max(szam3,szam4));
        System.out.println("Adjon meg egy 0-tól n-ig terjedő intervallumot(adja meg n-t): ");
        int n = input.nextInt();
        System.out.printf("egy random szám(0-%d intervallumon): %d\n",n,(int)(Math.random() * n));
        input.close();

    }
}