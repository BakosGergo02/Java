import java.util.Arrays;


public class Main
{
    public static void main(String[] args)
    {
        int[] tomb = { 2, 5, 1, 4, 3 };
        System.out.println(Arrays.toString(tomb));    // [2, 5, 1, 4, 3]
        MyArrayUtils.sortDescending(tomb);
        System.out.println(Arrays.toString(tomb));    // [5, 4, 3, 2, 1]
    }
}
class MyArrayUtils
{
    public static void sortDescending(int[] arr)
    {
        Arrays.sort(arr);

        for( int i = 0; i < arr.length/2; ++i )
            {
                int temp = arr[i];
                arr[i] = arr[arr.length - i - 1];
                arr[arr.length - i - 1] = temp;
            }
    }
}