import java.util.Scanner;


public class Main
{
    public static void main(String[] args)
    {
        System.out.println("Adjon meg egy szoveget: ");
        Scanner input = new Scanner(System.in);
        String[] arr= input.nextLine().split(" ");
        MyArrayUtils.reverse(arr);
        input.close();

    }
}
class MyArrayUtils
{
    public static void reverse(String[] arr){

        for (int i = arr.length - 1;i >= 0; i--)
        {
            String temp = arr[i];
            System.out.printf("%s ",temp);


        }
        System.out.println("\n");
    }
}