import java.util.Scanner;

public class Main
{
    public static void main(String[] args)
    {
        System.out.println("Adjon meg egy szöveget:");
        Scanner input = new Scanner(System.in);
        String szoveg = input.nextLine();
        input.close();
        Olvashato olvashato = new Olvashato();
        olvashato.olvashato(szoveg);
    }
}
class Olvashato
{
    public void olvashato(String s)
    {
        String[] szoveg = s.split("");
        for (int i = 0; i < szoveg.length; i++)
        {
            szoveg[i].replace('3', 'e');
            szoveg[i].replace('1', 'i');
            szoveg[i].replace('7', 't');
            szoveg[i].replace('4', 'a');
            szoveg[i].replace('5', 's');
            szoveg[i].replace('0', 'o');

        }

        for (int i = 0; i < szoveg.length; i++)
        {
            System.out.printf("%s ",szoveg[i]);
        }

    }
}