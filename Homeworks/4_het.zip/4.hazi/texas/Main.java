public class Main {
    public static void main(String[] args) {

        System.out.println(PyUtils.range(0, 5));
        System.out.println(PyUtils.range(3, 7));
        System.out.println(PyUtils.range(3,4));
        System.out.println(PyUtils.range(3,3));
        System.out.println(PyUtils.range(10));
        // ez a felső limit lesz. Ekkor az alsó limit alapértelmezetten 0 lesz.
        System.out.println(PyUtils.range(1));

        System.out.println(PyUtils.range(0));
        System.out.println(PyUtils.range(-4));
        System.out.println(PyUtils.range(4, 20, 2));
        // indulunk 4-ről; a 20 már nincs benne; lépésköz: 2, azaz vesszük minden második elemet
        System.out.println(PyUtils.range(4,10,1));
        System.out.println(PyUtils.range(10, 4, 1));
    }
}
