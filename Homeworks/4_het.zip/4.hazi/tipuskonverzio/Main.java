public class Main
{
    public static void main(String[] args)
    {
        long a = Long.parseLong("123");
        float b = Float.parseFloat("3.14");
        double c = Double.parseDouble("7.89");
        String e = "a";
        char d = e.charAt(0);

        System.out.println(a + b + c + d);
    }
}