import java.util.ArrayList;
import java.util.List;


public class Main {
    public static void main(String[] args) {
        List<Integer> szamok = new ArrayList<>(List.of(5, 6, 3, 9, 4, 2, 7, 99));
        szamok.add(1);

        MinMax minMax = findMinMax(szamok);
        System.out.println("Min: " + minMax.getMin() + ", Max: " + minMax.getMax());
    }
}