import java.util.List;

public class MinMax {
    public static MinMax findMinMax(List<Integer> list) {
        if (list.isEmpty()) {
            throw new IllegalArgumentException("The list cannot be empty.");
        }

        int min = list.get(0); // Kezdjük a legkisebbnek az első elemet
        int max = list.get(0); // Kezdjük a legnagyobbnak az első elemet

        // Iterálunk a lista elemein
        for (int i = 1; i < list.size(); i++) {
            int current = list.get(i);
            if (current < min) {
                min = current; // Frissítjük a minimumot
            }
            if (current > max) {
                max = current; // Frissítjük a maximumot
            }
        }

        return new MinMaxResult(min, max); // Visszatérünk a saját objektummal
    }
}