import java.util.List;

public class Main{
    public static void main(String[] args) {

        List<String> lines = FileUtils.readLines("input.txt");

        if (lines.isEmpty()) {
            System.out.println("Hiba! A fájl üres");
            return;
        }

        String input = lines.get(0);
        int sum = 0;
        int length = input.length();


        for (int i = 0; i < length; i++) {
            char currentChar = input.charAt(i);
            char nextChar = input.charAt((i + 1) % length);

            if (currentChar == nextChar) {
                sum += Character.getNumericValue(currentChar);
            }
        }

        System.out.println("Az összeg: " + sum);
    }
}
