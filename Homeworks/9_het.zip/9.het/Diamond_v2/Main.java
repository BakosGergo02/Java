public class Main {

    public static void Diamond(int height) {
        assert height % 2 != 0 : "Hiba: Csak páratlan magasság adható meg!";

        int middle = height / 2;

        //Felso
        for (int i = 0; i <= middle; i++) {
            int stars = 2 * i + 1;
            int spaces = middle - i;
            System.out.println(" ".repeat(spaces) + "*".repeat(stars));
        }

        //Also
        for (int i = middle - 1; i >= 0; i--) {
            int stars = 2 * i + 1;
            int spaces = middle - i;
            System.out.println(" ".repeat(spaces) + "*".repeat(stars));
        }
    }

    public static void main(String[] args) {

        Diamond(3);
        System.out.println();
        Diamond(7);
        System.out.println();
        Diamond(4);
    }
}
