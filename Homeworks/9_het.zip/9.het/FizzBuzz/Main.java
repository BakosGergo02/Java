public class Main{

    public static void main(String[] args) {
        FizzBuzz fb = new FizzBuzz(100);
        fb.start();
    }
}