import java.util.Random;

import kivetel.HibasIranyException;

public class Lift implements Mozog{
    private int emeletekSzama;
    private int aktualisEmelet;


    private static final Random RAND = new Random();

    public Lift(int emeletekSzama)
    {
        this.emeletekSzama = emeletekSzama;
        this.aktualisEmelet = RAND.nextInt(1,this.emeletekSzama+1);
    }
    

    @Override
    public void lefele() throws HibasIranyException, Exception {
       if (this.aktualisEmelet == 1) {
            throw new HibasIranyException("Nem tudunk lejjebb menni.");
       }

       elromol();
       this.aktualisEmelet--;
    }

    @Override
    public void felfele() throws HibasIranyException, Exception {
        if (this.aktualisEmelet == this.emeletekSzama ) {
            throw new HibasIranyException("Nem tudunk feljebb menni.");
        }

        elromol();
        this.aktualisEmelet++;
    }

    private static void elromol() throws Exception{
        if(RAND.nextInt(100) == 0)
        {
            throw new Exception("Elromolás");
        }
    }

    @Override
    public String toString() {
        return "Lift [emeletekSzama=" + emeletekSzama + ", aktualisEmelet=" + aktualisEmelet + "]";
    }
    
}
