import kivetel.HibasIranyException;

public interface Mozog {
    public void lefele() throws HibasIranyException, Exception;

    public void felfele() throws HibasIranyException, Exception;


}
