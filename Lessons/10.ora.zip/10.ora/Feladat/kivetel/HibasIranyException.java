package kivetel;

public class HibasIranyException extends Exception {
    public HibasIranyException(String message){
        
    }
}
