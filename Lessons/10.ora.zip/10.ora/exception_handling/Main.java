import java.util.Scanner;

public class Main{

    public static void main(String[] args) {
    
        Scanner sc = new Scanner(System.in);
    
        int num = 0;

        try {

            num = Integer.parseInt(sc.nextLine());

            throw new Exception("Error");
            
        } catch (NumberFormatException e)
        {
            e.printStackTrace();
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
        finally
        {
            sc.close();
            System.out.println("Always runs...");
        }
        System.out.println(num);
    }
}