import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

public class MyFileUtil {
    public static List<String> readAllLines(String fileName)
    {
        List<String> lines = new ArrayList<>();

        try(BufferedReader br = new BufferedReader(new FileReader(fileName))){

            String line;
            while ((line = br.readLine() )!= null) {
                lines.add(line);
            }
        }catch(FileNotFoundException e)
        {
            System.out.println("The file was not found.");
        }catch(IOException e){
            e.printStackTrace();
        }

        return lines;
    }

    public static void writeAllLines(String fileName, List<String> lines)
    {
        try(BufferedWriter bw = new BufferedWriter(new FileWriter(fileName))){

            for (String line : lines) {
                bw.write(line + "\n");
                bw.newLine();
            }
        }catch(FileNotFoundException e)
        {
            System.out.println("The file was not found.");
        }catch(IOException e){
            e.printStackTrace();
        }
    }

    public static void printAllLines(String fileName,List<String> lines){
        try (PrintWriter pw = new PrintWriter(fileName)){
            for (String line : lines) {
                pw.println(line);
            }
        } catch (FileNotFoundException e) {
            System.out.println("The file was not found.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


}
