import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class Main {
    public static void main(String[] args) {
        //List<String> list = new ArrayList<>();

        Set<Integer> set = new HashSet<>();

        set.add(5);
        set.add(10);
        set.add(15);
        set.add(20);
        set.add(20);

        System.out.println(set);

        set.remove(15);
        System.out.println(set);

        System.out.println(set.isEmpty());

        System.out.println(set.size());
        System.out.println(set.contains(25));
        //unió
        Set<Integer> set2 = new HashSet<>(List.of(1,2,3,4,5));

        set.addAll(set2);

        System.out.println(set);
        //metszet    retain -megtart
        set.retainAll(set2);

        System.out.println(set);

        // kulonbseg

        Set<Integer> set3 = new HashSet<>(List.of(1,2,3));
        set.removeAll(set3);
        System.out.println(set);

        List<Integer> li = new ArrayList<>(set);

        System.out.println(li);

        for (Integer num : set) {
            System.out.println(num);
            
        }
    }
}
