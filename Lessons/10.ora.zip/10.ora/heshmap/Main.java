import java.util.Map.Entry;
import java.util.HashMap;
import java.util.Map;


public class Main {
    public static void main(String[] args) {
        Map<String, Integer> fruitPrices = new HashMap<>();
        

        fruitPrices.put("apple", 100);
        fruitPrices.put("orange", 50);
        fruitPrices.put("grapes", 30);

        System.out.println(fruitPrices);

        fruitPrices.put("grapes", 40);

        System.out.println(fruitPrices);

        fruitPrices.remove("grapes");
        System.out.println(fruitPrices);

        System.out.println(fruitPrices.containsKey("apple"));

        System.out.println(fruitPrices.containsValue(30));

        for (Entry<String, Integer> entry : fruitPrices.entrySet()) {
            System.out.printf("Key=%s, Value=%d\n", entry.getKey(), entry.getValue());
        }

        System.out.println("--------------");
        for (String key : fruitPrices.keySet()) {
            System.out.printf("Key=%s, Value=%d\n",key, fruitPrices.get(key));
        }

        System.out.println("--------------");
        System.out.println(fruitPrices.values());

        System.out.println(fruitPrices.get("potato"));

        System.out.println(fruitPrices.getOrDefault("potato", 0));


    }
}
