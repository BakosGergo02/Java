import java.util.Scanner;

public class Main
{



    public static void main(String args[])
    {
        // String text1 = new String(original: "Esik az eső es sut a nap");
        // String text2 = "alma,korte,szilva";

        // System.out.println(text1);
        // System.out.println(text2);
        // System.out.println("-".repeat(count:10));

        // int hossz = text1.length();

        // System.out.println(hossz);

        // char c = text1

        // System.out.println(c);

        // String concatenated = text1 + " " + text2;

        // System.out.println(concatenated);

        // boolean result = text1.equalsIgnoreCase(text2);

        // System.out.println(result ? "Megegyeznek" : "különböznek");

        // String Word = text1.substring(beginIndex: 8, endIndex: 11);

        // System.out.println(Word);

        // text1 = text1.replace("z eso", replacement: "ho");

        // System.out.println(text1);

        // String[] gyumolcsok = text2.split(regex:",");

        // System.out.println(gyumolcsok)



      //  String nev = "Gergo";

       // int kor = 20;

        String szak = "MI";


        System.out.println("Nev: %s\nKor: %5d%%\nSzak: %s\n%3.2f", nev ,kor, szak, 3.1415123);

        String formazott = System.format("Nev: %s\nKor: %5d%%\nSzak: %s\n%3.2f", nev ,kor, szak, 3.1415123);

        System.out.println(formazott);


        Scanner scanner = new Scanner(System.in);
x
        System.out.print("Neved: ");
        String nev = scanner.nextLine();

        System.out.printf("A beirt ertek: %s\n", nev);

        System.out.print("Eletkor: ");

        int kor = scanner.nextInt();

        System.out.print( "Magassag cm: ");
        float magassag = scanner.nextFloat();
        scanner.close();


        System.out.printf("Nev: %s\nKor: %d\nMagassag: %.1f\n", nev,kor,magassag);




    }
}