import java.util.ArrayList;
import java.util.List;

public class Main{
    public static void main(String[] args) {
        int[] t = {1, 2 , 3, 4, 5};

        List<Integer> list1 = new ArrayList<>();
        list1.add(5);
        list1.add(10);

        /*for (int i = 0; i < list1.size(); i++) {
            System.out.println(list1.get(i));
        }*/


        for (Integer integer : list1) {
            System.out.println(integer);
        }

        list1.addFirst(100);
        System.out.println(list1);

        System.out.println(list1.contains(100));

    }
}