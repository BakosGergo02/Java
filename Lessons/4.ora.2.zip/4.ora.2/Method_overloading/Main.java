public class Main {

    public static void main(String[] args) {
        double res = Proba.add(5, 2);
        int res2 = Proba.add(5, 2,10);


        System.out.println(res);
        System.out.println(res2);
    }
}