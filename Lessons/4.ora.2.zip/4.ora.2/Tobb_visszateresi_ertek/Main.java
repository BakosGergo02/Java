import java.util.Arrays;

public class Main{
    public static void main(String[] args) {
        /*int[] t = {2,4,8,16,32};

        String s = Arrays.toString(getFirstAndLast(t));
        System.out.println(s);*/

        String str = "csőröge";

        Result r = getSubstringAndIndex(str, 1);
        System.out.println(r);


        int[] t2 =  {2,6,4,9};

        MinMax r2 = getMinMax(t2);
        System.out.println(r2);

    }


    public static MinMax getMinMax(int[] t)
    {
        int max = t[0];
        int min = t[0];
        for (int i : t) {
            min = Math.min(min,i);
            max = Math.max(max, i);
        }
        return new MinMax(min, max);
    }
    public static int[] getFirstAndLast(int[] t){
        int first = t[0];
        int last = t[t.length - 1];


        int[] res = {first,last};
        return res;
    }

    public static Result getSubstringAndIndex(String str, int i){
        String subString = str.substring(i);

        Result res = new Result(subString, i);
        return res;
    }
}