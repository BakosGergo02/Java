public class MinMax {
    public int min;
    public int max;

    public MinMax(int min2, int max2) {
        min2 = min;
        max2 = max;
    }

    @Override
    public String toString() {
        return "MinMax [min=" + min + ", max=" + max + "]";
    }



}
