public class Result {
    public String subString;
    public int Index;

    public Result(String subString, int Index)
    {
        this.subString = subString;
        this.Index = Index;
    }

    @Override
    public String toString() {
        return "Result [subString=" + subString + ", Index=" + Index + "]";
    }


}
