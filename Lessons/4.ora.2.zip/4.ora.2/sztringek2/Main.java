import java.util.ArrayList;
import java.util.List;

public class Main {

    public static void main(String[] args) {

        List<String> strs = new ArrayList<>();
        strs.clear();
        strs.add("alma");
        strs.add("korte");
        strs.add("banan");
        strs.add("abba");
        System.out.println(matchEnds(strs));
    }


    public static int matchEnds(List<String> list){
        int cnt = 0;

        for (String string : list) {
            if (2 <= string.length()){
                if (string.charAt(0) == string.charAt(string.length()-1)) {
                    cnt++;
                }
            }
        }
    }
}