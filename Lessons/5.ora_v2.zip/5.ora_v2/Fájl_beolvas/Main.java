import java.util.List;

public class Main {

    public static void main(String[] args) {
        List<String> lines = FileUtils.readLines("lines.txt");

        // int res = 0;
        // for (String line : lines) {
        //     res += Integer.parseInt(line);
        // }
        // System.out.println("osszeg: "+ res);

        // String[] parts = "a b c d e".split(" ");

        // for (String part : parts) {
        //     System.out.println(part);
        // }

        for (String line : lines) {
            String[] parts = line.split("-");
            String[] nums = parts[1].split(":");

            int sum = 0;
            for (String num : nums) {
                sum += Integer.parseInt(num);
            }

            System.out.println(sum);
        }
    }
}
