import java.util.ArrayList;
import java.util.List;

public class Main {

    public static void main(String[] args) {
        System.out.println(Character.isDigit('5'));
        System.out.println(Character.isWhitespace('\n'));

        System.out.println(Character.isUpperCase('A'));
        System.out.println(Character.toLowerCase('A'));

        System.out.println('9');
        System.out.println(Character.getName(9654));
        System.out.println((char)9654);

        List<Integer> nums = new ArrayList<>(List.of(1,2,3,4,5,6,7));
        String s = "";

        for (Integer integer : nums) {
                s = s+integer;
        }
        StringBuilder sb = new StringBuilder();
        for (Integer integer : nums) {
            sb.append(integer);
        }

        System.out.println(sb/*.toString()*/);
    }
}