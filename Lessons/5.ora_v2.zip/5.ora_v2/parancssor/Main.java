public class Main{
    public static void main(String[] args) {
        /*for (String string : args) {
            System.out.println(string);
        }*/

        if (args.length != 2)
        {
            System.err.println("hibas parameterezes");
            System.exit(1);
        }

        int res = Integer.parseInt((args[0])+ Integer.parseInt(args[1]));
        System.out.println(res);

        //osztaly szint
        //konstruktor, peldanyositas
        //To string
        //static method
    }
}