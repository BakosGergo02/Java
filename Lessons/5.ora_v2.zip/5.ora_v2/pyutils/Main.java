public class Main {
    public static void main(String[] args) {
        String s = PyUtils.input("Add meg a neved: ");
        System.out.println(s);
    }
}
