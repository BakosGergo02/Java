import java.util.Scanner;

public class PyUtils{

    public static String input(String s){
        Scanner scanner = new Scanner(System.in);
        System.out.print(s);
        String input = scanner.nextLine();
        scanner.close();
        return input;
    }
}