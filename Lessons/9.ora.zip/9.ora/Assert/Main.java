public class Main {
    public static void main(String[] args) {
        int i = 5;

        //assert i %2 == 0 : "i must be even";

        assert i  %2 == 0 : i % 2 == 0;

        System.out.println(i);

    }
}
