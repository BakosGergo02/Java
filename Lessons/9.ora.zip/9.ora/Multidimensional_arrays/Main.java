//import java.util.Arrays;

import java.util.Arrays;

public class Main{
    public static void main(String[] args) {
        int[][] mat = new int[3][];

        //mat[0] -> int[]
        mat[0] = new int[]{1, 2, 3};
        //mat[1] -> int[]
        mat[1] = new int[]{4, 5, 6};
        //mat[2] -> int[]
        mat[2] = new int[]{7, 8, 9};

        // 1 2 3 4 5 6

        int[][] mat2 = new int[][]
        {
            {1, 2, 3},
            {4, 5, 6},
            {7, 8, 9}
        };

        //System.out.println(Arrays.toString(mat2));
        System.out.println(Arrays.deepToString(mat2));

        for (int i = 0; i < mat2.length; i++) {
            for (int j = 0; j < mat2[i].length; j++) {
                System.out.print(mat2[i][j] + ", ");
            }
        }

        System.out.println("\n----");
        for (int[] innerArray : mat2) {
            for (int num : innerArray) {
                System.out.print(num + ", ");
            }
        }
        System.out.println("\n");


    }
}