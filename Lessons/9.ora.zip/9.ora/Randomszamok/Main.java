import java.util.Random;

public class Main {
    public static void main(String[] args) {
        System.out.println(Math.random());
        System.out.println(Math.random()*10);

        int randnum = (int)(Math.random() * ( 2+1));

        System.out.println(randnum);

        //(int)(random() * ((max-min+1)+min)) [min,max]


        int r = randRange(5,7);
        System.out.println( r );


        Random rand = new Random();
        System.out.println(rand.nextInt(5));        // [0,5]
        System.out.println(rand.nextInt(5, 10 +1)); // [5,10]


        System.out.println(rand.nextDouble(3.0, 3.5));

    }

    static int randRange(int min, int max){
        return (int)(Math.random() * ((max - min + 1) + min));
    }
}
