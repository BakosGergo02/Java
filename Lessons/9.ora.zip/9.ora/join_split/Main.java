import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        String ipAddr = "192.168.0.1";
        String manySpaces = "   a    b     c    \n\n     d        ";

        String[] parts = ipAddr.split("\\.");
        System.out.println(Arrays.toString(parts));

        String[] parts2 = manySpaces.trim().split("\\s+");

        System.out.println(Arrays.toString(parts2));

        String joined = String.join(":--:", parts2);
        System.out.println(joined);

    }
}
