public class Main {
    public static void main(String[] args) {
        String str = "";

        str = str + "5";

        
    }
}
