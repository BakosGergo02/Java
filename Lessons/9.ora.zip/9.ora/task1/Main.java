import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        //1. kérjünk a user-től egy egász számot (N)

        Scanner sc = new Scanner(System.in);

        Random rand = new Random();

        int N = sc.nextInt();

        int[][] mat = new int[N][N];

        
        for (int i = 0; i < mat.length; i++) {
            for (int j = 0; j < mat[i].length; j++) {
                mat[i][j] = rand.nextInt(10,20 +1);
            }
        }
        
        sc.close();
        System.out.println(Arrays.deepToString(mat));
        
    }
}
